﻿namespace admin
{
    internal class ADMIN_SELECTDataTable
    {
    }
}